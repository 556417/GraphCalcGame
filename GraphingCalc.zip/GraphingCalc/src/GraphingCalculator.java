import java.util.*;
import java.awt.*;
import java.awt.event.*;

/**@author Kaspar Winston, Richie Chen
 */
class GraphingCalculator extends Frame
{
    static String equationType;
    ArrayList<Integer> scores = new ArrayList<>();
    public static void main(String[] args) {
        int score = 0;
        boolean wacko = true;
        while (wacko) {
            new GraphingCalculator();
            boolean equationGuessed = false;
            Scanner joe = new Scanner(System.in);
            System.out.println("What is the type of equation?");
            while (!equationGuessed) {
                String guessedEquation = joe.nextLine();
                if (equationType.equals(guessedEquation)) {
                    equationGuessed = true;
                    System.out.println("Correct!");
                    score++;
                } else {
                    System.out.println("Wrong, game over!");
                    System.out.println("Score: " + score);
                    wacko = false;
                    break;
                }
            }
        }
    }
    /**
     * Method to set the conditions of the canvas and terminate the program when the wnidow is closed
     */
    GraphingCalculator()
    {
        super("Graphing Calculator");

        // Terminate when window is closed
        addWindowListener
                (
                        new WindowAdapter()
                        {
                            public void windowClosing(WindowEvent e)
                            {
                                System.exit(0);
                            }
                        }
                );
        setSize(1000, 1000);
        add("Center", new CvGraphingCalculator());
        setVisible(true);
    }

    class CvGraphingCalculator extends Canvas
    {
        /**
         * Calls both the drawGraph and equation classes to create the graph
         * @param g   the specified Graphics context
         */
        public void paint(Graphics g)
        {
            Dimension d;
            int maxX, maxY;

            // get the size of the canvas
            d = getSize();

            maxX = d.width - 1;
            maxY = d.height - 1;

            drawGraph(g, maxX, maxY);
            equation(g, maxX, maxY, 100, 100);
        }

        public class equationT {
            private int xCoef;
            private int yIntercept;
            /**
             * Base class for a linear equation
             * @param xCoef the coefficient for x
             * @param yIntercept the y intercept of the line
             */
            public equationT(int xCoef, int yIntercept) {
                this.xCoef =xCoef;
                this.yIntercept =yIntercept;
            }

            /**
             * Getter method
             */
            public int getXCoef(){
                return xCoef;
            }

            /**
             * Setter method
             * @param xCoef
             */
            public void setxCoef(int xCoef) {
                this.xCoef = xCoef;
            }

            /**
             * Getter method
             */
            public int getYIntercept(){
                return yIntercept;
            }
            /**
             * Setter method
             * @param yIntercept
             */
            public void setYIntercept(int yIntercept) {
                this.yIntercept = yIntercept;
            }

        }
        public class quadratic extends equationT{
            private int xSqrCoef;
            /**
             * Class for a quadratic equation
             * @param xCoef the coefficient for x
             * @param yIntercept the y intercept of the line
             * @param xSqrCoef the coefficient for x^2
             */
            public quadratic(int xCoef, int yIntercept, int xSqrCoef) {
                super(xCoef, yIntercept);
                this.xSqrCoef = xSqrCoef;
            }

            /**
             * Getter method
             */
            public int getXSqrCoef(){
                return xSqrCoef;
            }

            /**
             * Setter method
             * @param xSqrCoef
             */
            public void setXSqrCoef(int xSqrCoef) {
                this.xSqrCoef = xSqrCoef;
            }
        }

        public class sinusoidal extends equationT{
            private String trigThing;
            /**
             * Class for a sinusoidal equation
             * @param xCoef the coefficient for x
             * @param yIntercept the y intercept of the line
             * @param trigThing the trigonometric formula used in the equation
             */
            public sinusoidal(int xCoef, int yIntercept, String trigThing) {
                super(xCoef, yIntercept);
                this.trigThing = trigThing;
            }

            /**
             * Getter method
             */
            public String getTrigThing(){
                return trigThing;
            }
            /**
             * Setter method
             * @param trigThing
             */
            public void setTrigThing(String trigThing) {
                this.trigThing = trigThing;
            }

        }


        /**
         * Decides which type of equation to use and the value of the constants
         * @param g awt graphics
         * @param maxX max y coordinate (top and bottom edges of the graph)
         * @param maxY max y coordinate (right and left edges of the graph)
         * @param scale scale of the graph (how "zoomed in" it is)
         * @param resolution resolution of the graph (space between each point drawn; higher resolution = closer together)
         */
        void equation(Graphics g, int maxX, int maxY, int scale, int resolution)
        {
            float x, y;
            double dice = Math.random();
            equationT john;
            int yThing = (int)(Math.random()*3);
            int xThing = (int)(Math.random()*10);
            int xSqrThing = (int)(Math.random()*10);
            String[] trigList = {"Sin", "Cos", "Tan"};
            String trigEqu = trigList[(int)(3*Math.random())];

            // set the origin at the center of the canvas
            g.translate(maxX / 2, maxY / 2);

            g.setColor(Color.black);

            if (dice > 0.66){
                john = new equationT(xThing, yThing);
                equationType = "Linear";
                for (x = -(maxX / 2); x < maxX / 2; x += (float) .01 / resolution)
                {
                    y = (float)
                            -(
                                    // equation goes here
                                    xThing*x+yThing
                            );

                    g.drawLine(Math.round(x * scale), Math.round(y * scale), Math.round(x * scale), Math.round(y * scale));
                }
            }
            else if (dice > 0.33){
                john = new quadratic(xThing, yThing, xSqrThing);
                equationType = "Quadratic";
                for (x = -(maxX / 2); x < maxX / 2; x += (float) .01 / resolution)
                {
                    y = (float)
                            -(
                                    // equation goes here
                                    xSqrThing*Math.pow(x, 2) + xThing*x + yThing
                            );

                    g.drawLine(Math.round(x * scale), Math.round(y * scale), Math.round(x * scale), Math.round(y * scale));
                }
            }
            else{
                john = new sinusoidal(xThing, yThing, trigEqu);
                equationType = "Sinusoidal";
                for (x = -(maxX / 2); x < maxX / 2; x += (float) .01 / resolution)
                {
                    if(trigEqu.equals("Sin")){
                        y = (float) -(
                                // equation goes here
                                xThing*(Math.sin(x))+yThing
                            );
                    }
                    else if(trigEqu.equals("Cos")){
                        y = (float) -(
                                // equation goes here
                                xThing*(Math.cos(x))+yThing
                        );
                    }
                    else{
                        y = (float) -(
                                // equation goes here
                                xThing*(Math.tan(x))+yThing
                        );
                    }
                    g.drawLine(Math.round(x * scale), Math.round(y * scale), Math.round(x * scale), Math.round(y * scale));
                }
            }
        }

        /**
         * Creates the x and y axis for the graph
         * @param g awt graphics
         * @param maxX max y coordinate (top and bottom edges of the graph)
         * @param maxY max y coordinate (right and left edges of the graph)
         */
        void drawGraph(Graphics g, int maxX, int maxY)
        {
            int midX = maxX / 2;
            int midY = maxY / 2;

            // draw x and y axis
            g.setColor(Color.lightGray);
            g.drawLine(0, midY, maxX, midY);
            g.drawLine(midX, 0, midX, maxY);
        }
    }
}